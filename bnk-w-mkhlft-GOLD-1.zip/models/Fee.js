const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    userId : String,
    reason : String,
    amount : Number,
    index : Number
})

module.exports = mongoose.model("fees",schema)