const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    userId : String,
    bank : Number,
    cash : Number
})

module.exports = mongoose.model("bank",schema)