module.exports = {
    token: process.env.token, //التوكن
    prefix : "-", //برفكس
    mongoURI : process.env.db, //رابط مونجو
    embedColor :"#F5C913", //لون امبد
    line : "https://cdn.discordapp.com/attachments/1145749543145701537/1147394045769961602/ezgif-4-0b73e9cf38.gif", //رابط الخط
    bankAdmin :  "1144635776538259604", //  رتبة ادمن البنك
    guildId : "1144635775816835104", //ايدي سيرفرك
    ratebLog : "1144635778442473540", //ايدي رتبة روم اللوق
    feeAdmin : "1144635776244662338", //الرتبة اللي تعطي مخالفات
    feealladmin : "1144635776328540271", //الرتبة اللي تمسح كل المخالفات
}